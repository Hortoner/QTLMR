# QTLMR v2.4

(更新日期: 2025-3-21)

-   1.增加`gsMap`函数功能：
    -   `gsMap_py_install()`配置gsMap软件环境；
    -   `gsMap_format_sumstats()`	gsMap GWAS 汇总统计数据格式化；
    -   `gsMap_quick_mode()`使用gsMap进行遗传信息的细胞空间映射分析。
-   2.其它函数优化修复。


# QTLMR v2.3

(更新日期: 2025-3-17)

-   1.增加`PoPS`函数功能：
    -   `PoPS_py_install()`配置PoPS软件环境；
    -   `PoPS_munge_feature()`PoPS特征预处理函数；
    -   `PoPS_MAGMA()`使用MAGMA软件生成MAGMA分数；
    -   `PoPS_py_run()`使用PoPS进行基因优先评分分析；
    -   `PoPS_run() `PoPS分析。
-   2.增加完善`共定位`函数功能：
    -   `coloc_format_dat() `共定位基因组区域数据提取；
    -   废除`coloc_GWAS() `函数，重新完善为`coloc_abf() `函数；
    -   `coloc_susie()`SuSiE（单一效应之和）共定位分析。
-   3.增加`SMulTiXcan`函数功能：
    -   `MetaXcan_Harmonization() `对GWAS基因组版本转换以适配MetaXcan分析；
    -   `MetaXcan_imputation() `对GWAS结果的基因型插补以适配MetaXcan分析；
    -   `SPrediXcan() `使用GTEX v8 MAHR 预测模型进行S-PrediXcan分析；
    -   `SMulTiXcan()`使用SMulTiXcan进行跨组织TWAS分析。
-   4.增加`chrpos转rsid`函数功能：
    -   `tran_SNP_python() `使用python实现chrpos转rsid。
-   5.其它函数优化修复。


# QTLMR v2.2

(更新日期: 2025-2-22)

-   1.增加函数功能：
    -   `MiXeR_run()`一键式进行MiXeR分析；
    -   `FM_summary()`简化的贝叶斯精细映射方法（FM-summary）；
    -   `GCTA_fastBAT()`基于GCTA_fastBAT的gene-based关联分析研究；
    -   `GNOVA_run()`使用GNOVA进行遗传协方差分析；
    -   `LCV_run()`进行潜在因果变量分析；
    -   `PWCOCO_run()`使用PWCOCO进行成对条件与共定位分析；
    -   `TWAS_FOCUS_Multi_test()`循环多种组织FOCUS精细定位分析；
    -   `HDL_L()`使用HDL方法进行局部遗传相关性分析。
-   2.完善CPASSOC函数功能：
    -   `CPASSOC_meta_gwas()` 根据PMID: 28980259文献，完善对SNP进行成对LD修剪，默认过滤Z-scores绝对值大于1.96的SNP。
-   3.剔除FUSION函数绘制曼哈顿图参数。
-   4.修复FUCOS创建Python环境并更正`TWAS_FOCUS_test()`函数的ref_ld及locations参数。
-   5.其它函数优化修复。


# QTLMR v2.1

(更新日期: 2024-12-15)

-   1.增加LAVA函数功能：
    -   `LAVA_sample_overlap()`创建 LAVA 分析输入的sample overlap文件；
    -   `LAVA_run() `使用 LAVA 包对所有基因组位点执行双变量遗传相关性分析；
    -   `LAVA_bivarplot() `绘制双变量LAVA分析结果的散点图。
-   2.增加SUPERGNOVA函数功能：
    -   `SUPERGNOVA_py_install()` 配置SUPERGNOVA软件环境；
    -   `SUPERGNOVA_format_data()` 格式转换成SUPERGNOVA分析输入格式数据；
    -   `SUPERGNOVA_run()` 使用 SUPERGNOVA 进行局部遗传相关性分析。
-   3.增加百度网盘下载文件函数功能：
    -   `Baidu_py_install()` 配置百度网盘python环境；
    -   `Baidu_download()` 使用百度网盘下载文件。
-   4.数据格式转换与清洗函数优化修复。


# QTLMR v1.9

(更新日期: 2024-11-08)

-   1.增加MiXeR函数功能：
    -   `MiXeR_install()` 配置MiXeR软件环境；
    -   `MiXeR_format_dat()` MiXeR分析输入数据格式转换；
    -   `MiXeR_Univariate()` MiXeR单变量分析；
    -   `MiXeR_Univariate_visualize()` MiXeR单变量分析可视化；
    -   `MiXeR_Bivariate()` MiXeR双变量跨性状分析；
    -   `MiXeR_Bivariate_visualize()` MiXeR双变量跨性状分析可视化。
-   2.增加cond_conjFDR函数功能：
    -   `cond_conjFDR()` cond/conjFDR分析。
-   3.增加HDL函数功能：
    -   `HDL_h2()` 使用HDL包基于SNP的遗传力的高精度似然推断;
    -   `HDL_rg()` 使用HDL进行高精度似然推断遗传相关性分析;
    -   `HDL_rg_parallel()` 使用HDL包多核进行遗传相关性的高精度似然推断。
-   4.增加芬兰R12数据转换功能；
-   5.其它函数优化修复。

# QTLMR v1.8

(更新日期: 2024-10-2)

-   支持Linux服务器使用QTLMR包


# QTLMR v1.7

(更新日期: 2024-09-17)

-   1.增加GSMR函数功能：
    -   `GSMR2_QTLMR()` 基于广义汇总数据的孟德尔随机化分析；详见：<https://www.nature.com/articles/s43856-024-00473-3>、<https://yanglab.westlake.edu.cn/software/gsmr/>与<https://github.com/jianyanglab/gsmr2>。
-   2.增加MR-JTI函数功能：
    -   首先利用`JTI_predixcan_test()`或`JTI_SPrediXcan_test()`函数进行TWAS分析，获得阳性结果的基因。再利于`MR_JTI_Beta()`函数计算beta值及95% CI。软件官网：<https://github.com/gamazonlab/MR-JTI?tab=readme-ov-file>。参考数据下载地址：<https://zenodo.org/records/3842289>。
-   3.增加可视化绘图函数功能：
    -   `Visualizing_MR_forest()`实现一键式绘制孟德尔随机化结果森林图，输入数据框格式为`mr()`或`GSMR2_QTLMR()`输出结果格式，其他数据绘制森林图可根据该格式修改；
    -   `Visualizing_Manhattan()`绘制曼哈顿图，为CMplot包的汉化版，详细教程可参考帮助文档或官网：<https://github.com/YinLiLin/CMplot/tree/master>。
-   4.增加其他函数功能：
    -   `clump_LD_R2()`获取连锁的SNP；
    -   `data_info_cytoBand()`获取cytoBand汇总信息数据。  
-   5.优化HESS软件底层代码：
    -   `HESS_estimate_correlation()`官方hess软件无全局遗传相关性p值计算；本版本对hess软件底层代码进行优化，增加全局遗传相关性p值计算。
-   6.其它函数优化修复。


# QTLMR v1.6

(更新日期: 2024-08-25)

-   1.增加S-LDSC与LDSC-SEG函数功能：
    -   `LDSC_py_ph()` 使用ldsc软件进行分区遗传力计算；
    -   `LDSC_py_SEG()`使用ldsc软件进行组织或细胞类型特异性分析。
-   2.增加hess软件模块函数功能：
    -   `HESS_install()` 配置HESS软件环境；
    -   `HESS_format_data()`将TwosampleMR格式转换成HESS分析输入格式数据；
    -   `HESS_estimate_heritability()`使用HESS软件计算局部SNP遗传力及标准误差；
    -   `HESS_estimate_correlation()`使用HESS软件计算性状遗传协方差和相关性(ρ-HESS)；
    -   `HESS_estimate_lambdagc()` 使用HESS软件计算基因组控制因子；
    -   `HESS_estimate_phenocor()` 使用HESS软件计算性状表型的相关性；
    -   `HESS_Visualizing_estimates()` 使用HESS软件绘制SNP遗传度或协方差的曼哈顿图；
    -   `HESS_Contrast_polygenicity()` 使用HESS软件绘制性状之间多基因性对比度的图；
    -   `HESS_putative_causality()` 使用HESS软件推断性状特征之间因果关系并绘图。
-   3.增加跨性状关联分析函数功能：
    -   `MTAG_install()` 配置MTAG软件环境；
    -   `MTAG_cross_gwas()` 使用MTAG进行跨性状表型meta分析；
    -   `META_CPASSOC_cross_gwas()` 使用cpassoc跨性状关联分析。
-   4.增加PLACO分析函数功能：
    -   `PLACO_analysis()` 	使用PLACO进行复合零假设下的多效性分析。
-   5.其它函数优化修复。

# QTLMR v1.5

(更新日期: 2024-07-27)

-   1.重新优化1.4版本函数：
    -   `available_outcomes_ieu()` IEU Open GWAS数据库表型汇总表；
    -   `data_info_GTEx_V8_GENE()`GTEx_V8基因信息汇总数据；
    -   `Gene_start_end_info_modified()`从内置数据中直接获取不同版本Ensembl id与Gene汇总信息数据；
    -   `coloc_GWAS()`对共定位函数进行优化，可自由选择是否locuscomparer作图，返回结果进行优化处理，方便直接保存使用；
    -   `coloc_stack_assoc_plot()`优化绘图时，可选择性只显示最显著的topSNP；
    -   `format_dat()`数据格式转换与清洗，功能类似TwoSampleMR::format_data()函数，可自动保存标准TwosampleMR、SMR、METAL文件。
-   2.增加“跨组织关联研究寻找疾病易感基因”全流程代码：
    -   具体可查看网站：<https://hortoner.github.io/QTLMR/articles/index.html>。

# QTLMR v1.4

(更新日期: 2024-07-20)

-   1.增加函数功能
    -   1.1 增加"MAGMA软件分析"功能：
    -   `MAGMA_gene_based()`函数进行gene-based & gene-set-based关联分析；
    -   `MAGMA_Tissue_specific()`进行交叉组织特异性分析；
    -   `MAGMA_genes_Manhattanplot()`对MAGMA软件gene_based分析结果的基因注释及曼哈顿图绘制；
    -   `MAGMA_gsa_barplot()`用于组织特异性和途径富集分析结果图形可视化。
    -   （详细请见 "./QTLMR test/版本升级文件/1.4版本" 文件夹下的示例代码）
    -   1.2 完善"使用UTMOST软件进行跨组织联合TWAS分析"功能：
    -   `TWAS_UTMOST_cross_tissue_test()`函数可将`TWAS_UTMOST_single_tissue_test()`结果进行跨组织联合分析，依赖的数据下载地址：<https://zhaocenter.org/UTMOST>。
    -   1.3 增加"数据转换与清洗"功能：
    -   `format_dat()`函数可将读入至R环境变量中的数据转换成标准TwosampleMR、SMR、METAL文件。
    -   1.4 增加"提取原始本地xQTL数据的顺式区域数据"功能：
    -   `xQTL_cis_dat()`函数可将原始的xQTL数据，根据基因编码的起始与终止位置的上下游区域范围内的SNP提取出来，以便进一步使用`coloc_GWAS()`进行后续的共定位分析，或使用`SMR_format_BESD()`函数转换成SMR分析所需的BESD二进制数据文件进行SMR分析，完善非R包内置xQTL数据的清洗与转换功能。
    -   1.5 增加"韦恩图绘制"功能：
    -   `venn_plot()`函数绘制韦恩图，示例数据（详细请见 "./QTLMR test/版本升级文件/1.4版本" venn文件夹）。
-   2.优化R包帮助页面。

# QTLMR v1.3

(更新日期: 2024-06-29)

-   1.增加函数功能：
    -   增加"获取传统药靶基因工具变量"功能；
    -   `get_Drugs_gene_IVs()`函数可从基因靶向的Twosample格式完整GWAS数据文件中提取指定靶基因的工具变量；或指定IEU Open GWAS数据库的id号提取数据，以此为暴露数据进行药靶MR分析。（详细请见 "./QTLMR test/版本升级文件/1.3版本" 文件夹下的示例代码）
-   2.同步芬兰数据库更新至R11：
    -   `data_info_finngen()`函数同步更新汇总信息数据至R11，`format_data_FinnGen()`同时支持R11数据清洗。

# QTLMR v1.2

(更新日期: 2024-06-14)

-   1.增加FOCUS功能：
    -   1.1 `TWAS_FOCUS_install()`函数配置FOCUS环境需要科学上网，网络不稳定，容易配置失败；建议本地安装，将“./QTLMR test/版本升级文件/1.2版本/FOCUS环境配置/FOCUS.zip”中的FOCUS.zip文件，直接解压到miniconda3安装路径的 "./miniconda3/envs" 文件下；
    -   1.2 `TWAS_FOCUS_format_data()`函数将GWAS数据转换成FOCUS输入文件；
    -   1.3 `TWAS_FOCUS_import()` 因FOCUS不能直接使用FUSION的权重数据文件，需要根据FUSION的权重数据文件转换成FOCUS软件识别的.db格式权重数据，此步耗时比较长；
    -   1.4 `TWAS_FOCUS_test()` 进行TWAS的基因-性状关联信号精细定位分析，ref_ld_dir的输入参数为./QTLMR test/inputdata/LDREF.zip中DREF.zip文件解压后的文件夹路径。此步耗时较长；
    -   详细请见 "./QTLMR test/版本升级文件/1.2版本" 文件夹下的示例代码。
-   2.函数更新：
    -   `TWAS_fusion_assoc_test()`
    -   `TWAS_fusion_conditonal_test()`
    -   `TWAS_fusion_Multi_test()`
    -   `TWAS_UTMOST_single_tissue_test()`
    -   `LDSC_py_rg()`
    -   `LDSC_py_h2()`
    -   分别增加了test_help、opt_arguments参数，类似test_help的参数能查看原始相应软件函数的帮助文档，opt_arguments可添加传递原始软件中R语言函数没有的参数，以便能够完全使用该软件的所有参数功能；
    -   `format_data_Catalog()`重新构建函数参数，将GWAS Catalog数据库.gz或.tsv文件转换为标准TwosampleMR、SMR、METAL文件。
